SUPERMARKET BILLING SYSTEM - CORRECTED STARTER

What changed in this version:
1. Product add/edit/delete now call Supabase instead of only changing browser local storage.
2. Product fetch maps cost_price, supplier, and expiry_date from Supabase.
3. Product save writes the product row and its inventory row.
4. Product deletion removes the database row (inventory is removed through the existing foreign-key cascade).
5. Added SQL columns for cost_price, supplier, and expiry_date without dropping existing data.

IMPORTANT
- This is the first correction pass for PRODUCT + INVENTORY persistence. Bills, customers, payments, reports, settings, and stock movement history still have local-storage-based parts and should be connected to Supabase in a later pass.
- Staff must sign in using an actual Supabase Auth user. Do not put a service_role key in app.js.
- Before running the full SQL file on a live database, review it first: it includes the project's seed/demo data as well as schema and RLS setup. For an existing database, use supabase_product_migration.sql first.
- The frontend expects the existing RLS policies to allow authenticated staff users to manage products and inventory.
- JavaScript syntax check passed (node --check). This does not replace testing against your actual Supabase project.
