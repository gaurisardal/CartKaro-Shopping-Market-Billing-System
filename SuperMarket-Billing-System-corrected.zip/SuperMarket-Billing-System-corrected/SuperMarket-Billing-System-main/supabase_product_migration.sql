-- Supermarket Billing System: product form/database alignment
-- Run this once in Supabase SQL Editor. Safe for existing product rows.
-- It does not delete or reset any tables or data.

alter table public.products add column if not exists cost_price numeric(10,2) check (cost_price >= 0);
alter table public.products add column if not exists supplier text;
alter table public.products add column if not exists expiry_date date;
